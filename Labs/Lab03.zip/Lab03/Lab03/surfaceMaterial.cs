﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab03
{
    public class surfaceMaterial : Desk
    {
        public int materialId
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string materialName
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public float materialCost
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab03
{
    class Program
    {
            static int readValue(
            string prompt, // prompt for the user
            int size // size
            )
            {
                int result = 0;
                do
                {
                    Console.WriteLine(prompt +
                    size);
                    string resultString = Console.ReadLine();
                    result = int.Parse(resultString);
                } while (result == 0);
                return result;
            }

        static void Main(string[] args)
        {
            int deskWidth = readValue("Enter width of desk: ", 0);
            Console.WriteLine("Width: " + deskWidth);
            int deskLength = readValue("Enter length of desk: ", 0);
            Console.WriteLine("Length: " + deskLength);
            string[] SurfaceMaterial = new string[2];
            SurfaceMaterial[0] = "Oak";
            SurfaceMaterial[1] = "Laminate";
            SurfaceMaterial[2] = "Pine";
            Console.WriteLine("Select Surface Material: ");
            int numOfDrawers = readValue("Enter Number of Drawers: ", 0);
            Console.WriteLine("Number of Drawers: ", 0);
            

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab03
{
    public class Order
    {

        public int DeskSize
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int RushOrderOption
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int Property
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public void createOrder()
        {
            throw new System.NotImplementedException();
        }
    }
}
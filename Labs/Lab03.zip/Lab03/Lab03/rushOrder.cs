﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab03
{
    public class rushOrder : Order
    {
        public int rushOrderId
        {
            
        }

        public int rushDay
        {
            
        }

        public int rushSize
        {
            
        }

        public float rushAmt
        {
            
        }
    }
}